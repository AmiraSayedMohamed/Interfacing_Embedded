/*
 * Digital Input/Output (DIO) Interface
 *
 * This header file defines the interface for controlling digital input and output operations on the ATMega32 microcontroller.
 *
 * It defines constants for port identifiers, pin numbers, direction options, and value options. It also declares the DIO control functions.
 *
 * Created: 11/4/2024 10:09:26 PM
 * Author: Eng_Amira
 */



#ifndef DIO_INTERFACE_H_
#define DIO_INTERFACE_H_

/* Ports IDs Defines */
#define PORTA_ID	0
#define PORTB_ID	1
#define PORTC_ID	2
#define PORTD_ID	3

/* Pins IDs Defines */
enum {
	PIN0,
	PIN1,
	PIN2,
	PIN3,
	PIN4,
	PIN5,
	PIN6,
	PIN7,
	};

/* Directions */
#define INPUT	0
#define OUTPUT	1
/* value options */
#define HIGH 1
#define LOW	 0
 
/**********************************************************************************************/
/**********************************************************************************************/
/* 
 * Function: MDIO_voidSetPinDir
 * Description: Sets the direction (INPUT/OUTPUT) of a specific pin on a specific port.
 * Input: copy_u8PortId (ID of the port), copy_u8PinId (ID of the pin), copy_u8PinDir (Direction to be set).
 * Output: None.
 */
/**********************************************************************************************/
/**********************************************************************************************/
void MDIO_voidSetPinDir(u8 copy_u8PortId , u8 copy_u8PinId , u8 copy_u8PinDir);


/**********************************************************************************************/
/**********************************************************************************************/
/* 
 * Function: MDIO_voidSetPinValue
 * Description: Sets the value (HIGH/LOW) of a specific pin on a specific port.
 * Input: copy_u8PortId (ID of the port), copy_u8PinId (ID of the pin), copy_u8PinValue (Value to be set).
 * Output: None.
 */
/**********************************************************************************************/
/**********************************************************************************************/
void MDIO_voidSetPinValue(u8 copy_u8PortId, u8 copy_u8PinId , u8 copy_u8PinValue);


/**********************************************************************************************/
/**********************************************************************************************/
/* 
 * Function: MDIO_u8GetPinValue
 * Description: Gets the current value (HIGH/LOW) of a specific pin on a specific port.
 * Input: copy_u8PortId (ID of the port), copy_u8PinId (ID of the pin).
 * Output: u8 (Current value of the pin).
 */
/**********************************************************************************************/
/**********************************************************************************************/
u8 MDIO_u8GetPinValue(u8 copy_u8PortId,u8 copy_u8PinId);


/**********************************************************************************************/
/**********************************************************************************************/
/* 
 * Function: MDIO_voidTogPinValue
 * Description: Toggles the value (HIGH/LOW) of a specific pin on a specific port.
 * Input: copy_u8PortId (ID of the port), copy_u8PinId (ID of the pin).
 * Output: None.
 */
/**********************************************************************************************/
/**********************************************************************************************/
void MDIO_voidTogPinValue(u8 copy_u8PortId , u8 copy_u8PinId);


/**********************************************************************************************/
/**********************************************************************************************/
/* 
 * Function: MDIO_voidSetPortDir
 * Description: Sets the direction (INPUT/OUTPUT) of all pins on a specific port.
 * Input: copy_u8PortId (ID of the port), copy_u8PortDir (Direction to be set for all pins).
 * Output: None.
 */
/**********************************************************************************************/
/**********************************************************************************************/
void MDIO_voidSetPortDir(u8 copy_u8PortId , u8 copy_u8PortDir);


/**********************************************************************************************/
/**********************************************************************************************/
/* 
 * Function: MDIO_voidSetPortValue
 * Description: Sets the value (HIGH/LOW) of all pins on a specific port.
 * Input: copy_u8PortId (ID of the port), copy_u8PortValue (Value to be set for all pins).
 * Output: None.
 */
/**********************************************************************************************/
/**********************************************************************************************/
void MDIO_voidSetPortValue(u8 copy_u8PortId , u8 copy_u8PortValue);


/**********************************************************************************************/
/**********************************************************************************************/
/* 
 * Function: MDIO_u8GetPortValue
 * Description: Gets the current value of all pins on a specific port.
 * Input: copy_u8PortId (ID of the port).
 * Output: u8 (Current values of all pins on the port).
 */
/**********************************************************************************************/
/**********************************************************************************************/
u8 MDIO_u8GetPortValue(u8 copy_u8PortId);


/**********************************************************************************************/
/**********************************************************************************************/
/* 
 * Function: MDIO_voidTogPortValue
 * Description: Toggles the value (HIGH/LOW) of all pins on a specific port.
 * Input: copy_u8PortId (ID of the port).
 * Output: None.
 */
/***********************************************************************************************/
/**********************************************************************************************/
void MDIO_voidTogPortValue(u8 copy_u8PortId);



#endif /* DIO_INTERFACE_H_ */