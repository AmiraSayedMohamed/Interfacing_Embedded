/*
 * Digital Input/Output (DIO) Program
 *
 * This file contains the implementation of functions to control digital input and output pins on the ATMega32 microcontroller.
 *
 * Functions include setting pin directions, setting pin values, reading pin values, toggling pin values, setting port directions, setting port values, reading port values, and toggling port values.
 *
 * Created: 11/4/2024 10:09:02 PM
 * Author: Eng_Amira
 */


#include "../../library/STD_Types.h"
#include "../../library/BIT_MATH.h"
#include "DIO_Interface.h"
#include "DIO_Private.h"
#include "DIO_Config.h"

/*
 * Sets the direction (input or output) of a specific pin within a port.
 * Parameters:
 *    copy_u8PortId - the ID of the port where the pin resides (PORTA_ID, PORTB_ID, PORTC_ID, PORTD_ID).
 *    copy_u8PinId - the ID of the pin whose direction is to be set (PIN0, PIN1, ..., PIN7).
 *    copy_u8PinDir - the direction to set for the specified pin (INPUT or OUTPUT).
 * Note: The function checks if the provided port and pin IDs are within valid ranges before setting the pin direction.
 */


void MDIO_voidSetPinDir(u8 copy_u8PortId , u8 copy_u8PinId , u8 copy_u8PinDir) {
	
	if (copy_u8PortId >= PORTA_ID && copy_u8PortId <= PORTD_ID && copy_u8PinId >= PIN0 && copy_u8PinId <= PIN7)
	{
		if (copy_u8PinDir == OUTPUT)
		{
			switch (copy_u8PortId){
				case PORTA_ID : SET_BIT(DDRA_REG,copy_u8PinId); break;
				case PORTB_ID : SET_BIT(DDRB_REG,copy_u8PinId); break;
				case PORTC_ID : SET_BIT(DDRC_REG,copy_u8PinId); break;
				case PORTD_ID : SET_BIT(DDRD_REG,copy_u8PinId); break;
			}
		}
		else if (copy_u8PinDir == INPUT) {
			switch (copy_u8PortId){
			case PORTA_ID : CLR_BIT(DDRA_REG,copy_u8PinId); break;
			case PORTB_ID : CLR_BIT(DDRB_REG,copy_u8PinId); break;
			case PORTC_ID : CLR_BIT(DDRC_REG,copy_u8PinId); break;
			case PORTD_ID : CLR_BIT(DDRD_REG,copy_u8PinId); break;
			}
		} 
		
	} 
	
	
}

/*
 * Sets the output value (high or low) of a specific pin within a port.
 * Parameters:
 *    copy_u8PortId - the ID of the port where the pin resides (PORTA_ID, PORTB_ID, PORTC_ID, PORTD_ID).
 *    copy_u8PinId - the ID of the pin whose value is to be set (PIN0, PIN1, ..., PIN7).
 *    copy_u8PinValue - the value to set for the specified pin (HIGH or LOW).
 * Note: The function checks if the provided port and pin IDs are within valid ranges before setting the pin value.
 */

void MDIO_voidSetPinValue(u8 copy_u8PortId, u8 copy_u8PinId , u8 copy_u8PinValue) {
	if (copy_u8PortId >= PORTA_ID && copy_u8PortId <= PORTD_ID && copy_u8PinId >= PIN0 && copy_u8PinId <= PIN7) {
		if ( copy_u8PinValue == HIGH)
		{
			switch (copy_u8PortId)
			{
			case PORTA_ID: SET_BIT(PORTA_REG,copy_u8PinId); break;
			case PORTB_ID: SET_BIT(PORTB_REG,copy_u8PinId); break;
			case PORTC_ID: SET_BIT(PORTC_REG,copy_u8PinId); break;
			case PORTD_ID: SET_BIT(PORTD_REG,copy_u8PinId); break;
			}
		} 
		else if (copy_u8PinValue == LOW) {
			switch (copy_u8PortId) {
				case PORTA_ID: CLR_BIT(PORTA_REG,copy_u8PinId); break;
				case PORTB_ID: CLR_BIT(PORTB_REG,copy_u8PinId); break;
				case PORTC_ID: CLR_BIT(PORTC_REG,copy_u8PinId); break;
				case PORTD_ID: CLR_BIT(PORTD_REG,copy_u8PinId); break;
			}
		}
		
		}
	
	
}

/*
 * Reads and returns the current value (high or low) of a specific pin within a port.
 * Parameters:
 *    copy_u8PortId - the ID of the port where the pin resides (PORTA_ID, PORTB_ID, PORTC_ID, PORTD_ID).
 *    copy_u8PinId - the ID of the pin whose value is to be read (PIN0, PIN1, ..., PIN7).
 * Returns: The current value of the specified pin (HIGH or LOW).
 * Note: The function checks if the provided port and pin IDs are within valid ranges before reading the pin value.
 */

u8 MDIO_u8GetPinValue(u8 copy_u8PortId,u8 copy_u8PinId){
	if (copy_u8PortId >= PORTA_ID && copy_u8PortId <= PORTD_ID && copy_u8PinId >= PIN0 && copy_u8PinId <= PIN7) { 
		u8 local_u8PinValue = 0 ;
		switch (copy_u8PortId)
		{
		case PORTA_ID: local_u8PinValue = GET_BIT(PINA_REG,copy_u8PinId); break;
		case PORTB_ID: local_u8PinValue = GET_BIT(PINB_REG,copy_u8PinId); break;
		case PORTC_ID: local_u8PinValue = GET_BIT(PINC_REG,copy_u8PinId); break;
		case PORTD_ID: local_u8PinValue = GET_BIT(PIND_REG,copy_u8PinId); break;
			
		}
		return local_u8PinValue;
	} 

}

/*
 * Toggles the output value (high to low, or low to high) of a specific pin within a port.
 * Parameters:
 *    copy_u8PortId - the ID of the port where the pin resides (PORTA_ID, PORTB_ID, PORTC_ID, PORTD_ID).
 *    copy_u8PinId - the ID of the pin whose value is to be toggled (PIN0, PIN1, ..., PIN7).
 * Note: The function checks if the provided port and pin IDs are within valid ranges before toggling the pin value.
 */

void MDIO_voidTogPinValue(u8 copy_u8PortId , u8 copy_u8PinId){
	if (copy_u8PortId >= PORTA_ID && copy_u8PortId <= PORTD_ID && copy_u8PinId >= PIN0 && copy_u8PinId <= PIN7)
	{ 
		switch (copy_u8PortId)
		{
			case PORTA_ID: TOG_BIT(PORTA_REG,copy_u8PinId); break;
			case PORTB_ID: TOG_BIT(PORTB_REG,copy_u8PinId); break;
			case PORTC_ID: TOG_BIT(PORTC_REG,copy_u8PinId); break;
			case PORTD_ID: TOG_BIT(PORTD_REG,copy_u8PinId); break;
		}
		
	}

}

/*
 * Sets the direction (input or output) of all pins within a port.
 * Parameters:
 *    copy_u8PortId - the ID of the port whose pins' directions are to be set (PORTA_ID, PORTB_ID, PORTC_ID, PORTD_ID).
 *    copy_u8PortDir - the direction to set for all pins in the specified port (INPUT or OUTPUT).
 * Note: The function checks if the provided port ID is within the valid range before setting the port direction.
 */


void MDIO_voidSetPortDir(u8 copy_u8PortId , u8 copy_u8PortDir){
	if (copy_u8PortId >= PORTA_ID && copy_u8PortId <= PORTD_ID) {
		if (copy_u8PortDir == INPUT) {
			switch (copy_u8PortId) {
				case PORTA_ID:
				DDRA_REG &= 0x00;
				break;
				case PORTB_ID:
				DDRB_REG &= 0x00;
				break;
				case PORTC_ID:
				DDRC_REG &= 0x00;
				break;
				case PORTD_ID:
				DDRD_REG &= 0x00;
				break;
				default:
				/* ERROR */
				break;
			}
		}
		else if (copy_u8PortDir == OUTPUT)
		{
			switch (copy_u8PortId)
			{
				case PORTA_ID:
				DDRA_REG |= 0xFF;
				break;
				case PORTB_ID:
				DDRB_REG |= 0xFF;
				break;
				case PORTC_ID:
				DDRC_REG |= 0xFF;
				break;
				case PORTD_ID:
				DDRD_REG |= 0xFF; // 0b11111111
				break;
				default:
				/* ERROR */
				break;
			}
		}
	}
	else
	{
	}
}

/*
 * Sets the output values (high or low) of all pins within a port.
 * Parameters:
 *    copy_u8PortId - the ID of the port whose pins' values are to be set (PORTA_ID, PORTB_ID, PORTC_ID, PORTD_ID).
 *    copy_u8PortValue - the values to set for all pins in the specified port (8-bit value, each bit corresponding to a pin).
 * Note: The function checks if the provided port ID is within the valid range before setting the port values.
 */


void MDIO_voidSetPortValue(u8 copy_u8PortId , u8 copy_u8PortValue){
	if (copy_u8PortId >= PORTA_ID && copy_u8PortId <= PORTD_ID )
	{ 
	switch (copy_u8PortId) {
		case PORTA_ID:
		PORTA_REG = copy_u8PortValue; 
		break;
		case PORTB_ID:
		PORTB_REG = copy_u8PortValue;
		break;
		case PORTC_ID:
		PORTC_REG = copy_u8PortValue;
		break;
		case PORTD_ID:
		PORTD_REG = copy_u8PortValue;
		break;
		default:
		/* ERROR */
		break;
	}
	}
	else
	{
	}
}

/*
 * Reads and returns the current values (high or low) of all pins within a port.
 * Parameters:
 *    copy_u8PortId - the ID of the port whose pins' values are to be read (PORTA_ID, PORTB_ID, PORTC_ID, PORTD_ID).
 * Returns: The current values of all pins in the specified port (8-bit value, each bit corresponding to a pin).
 * Note: The function checks if the provided port ID is within the valid range before reading the port values.
 */


u8 MDIO_u8GetPortValue(u8 copy_u8PortId){
	
if (copy_u8PortId >= PORTA_ID && copy_u8PortId <= PORTD_ID )
{
	switch (copy_u8PortId)
	{
		case PORTA_ID:
		return PORTA_REG; 
		break;
		case PORTB_ID:
		return PORTB_REG;
		break;
		case PORTC_ID:
		return PORTC_REG;
		break;
		case PORTD_ID:
		return PORTD_REG;
		break;
		default:
		/* ERROR */
		break;
	}
}
else
{
	return 0;
}
}

/*
 * Toggles the output values (high to low, or low to high) of all pins within a port.
 * Parameters:
 *    copy_u8PortId - the ID of the port whose pins' values are to be toggled (PORTA_ID, PORTB_ID, PORTC_ID, PORTD_ID).
 * Note: The function checks if the provided port ID is within the valid range before toggling the port values.
 */


void MDIO_voidTogPortValue(u8 copy_u8PortId){
	if (copy_u8PortId >= PORTA_ID && copy_u8PortId <= PORTD_ID )
	{
		switch (copy_u8PortId)
		{
			case PORTA_ID:
			PORTA_REG ^= 0xFF;
			break;
			case PORTB_ID:
			PORTB_REG ^= 0xFF ;
			break;
			case PORTC_ID:
			PORTC_REG ^= 0xFF ;
			break;
			case PORTD_ID:
			PORTD_REG ^= 0xFF ;
			break;
			default:
			/* ERROR */
			break;
		}
	}
}

