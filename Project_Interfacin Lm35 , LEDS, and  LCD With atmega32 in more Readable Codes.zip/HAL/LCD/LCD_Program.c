/*
 * LCD_Program.c
 *
 * Created: 4/14/2024 3:10:50 PM
 *  Author: PC
 */ 


#include <util/delay.h>
#include "../../library/STD_Types.h"
#include "../../MCAL/GPIO/DIO_Interface.h"
#include "lcdInterface.h"
#include <avr/io.h>

#ifndef F_CPU
# define F_CPU 10000000UL // clock speed is 16MHz
#endif

/*
 -----------                   ----------
 | ATmega32  |                 |   LCD    |
 |           |                 |          |
 |        PB7|---------------->|D7        |
 |        PB6|---------------->|D6        |
 |        PB5|---------------->|D5        |
 |        PB4|---------------->|D4        |
 |        PB3|---------------->|D3        |
 |        PB2|---------------->|D2        |
 |        PB1|---------------->|D1        |
 |        PB0|---------------->|D0        |
 |           |                 |          |
 |        PD5|---------------->|E         |
 |        GND|---------------->|RW        |
 |        PD6|---------------->|RS        |
 -----------                   ----------
 */


void send_a_command(unsigned char command) {

	PORTB = command;
	PORTD &= ~ (1<<registerselection);
	PORTD |= 1<<enable;
	_delay_ms(20);
	PORTD &= ~1<<enable;
	PORTB = 0;
}

void send_a_character(unsigned char character) {

	PORTB = character;
	PORTD |= 1<<registerselection;
	PORTD |= 1<<enable;
	_delay_ms(20);
	PORTD &= ~1<<enable;
	PORTB = 0;
}

void send_a_string(char *string_of_characters) {

	while(*string_of_characters > 0) {

		send_a_character(*string_of_characters++);

	}

}