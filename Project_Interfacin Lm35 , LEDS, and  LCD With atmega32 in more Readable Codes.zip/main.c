#include "library/STD_Types.h"
#include "library/BIT_MATH.h"
#include "MCAL/GPIO/DIO_Interface.h"
#include "HAL/LCD/lcdInterface.h"
#include <avr/io.h>
#include <util/delay.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

int main(void) {
	
	MDIO_voidSetPinDir(PORTC_ID, PIN0 , OUTPUT);
	MDIO_voidSetPinDir(PORTC_ID, PIN1 , OUTPUT);
	MDIO_voidSetPinDir(PORTC_ID, PIN2 , OUTPUT);
	MDIO_voidSetPinValue(PORTC_ID, PIN0 , LOW);   //Yellow
	MDIO_voidSetPinValue(PORTC_ID, PIN1 , LOW);   // Red
	MDIO_voidSetPinValue(PORTC_ID, PIN2 , LOW);    // Green

	
   MDIO_voidSetPortDir(PORTB_ID , OUTPUT);  // Define port B as output
   MDIO_voidSetPortDir(PORTA_ID , INPUT);    // Define port A as Input
   MDIO_voidSetPortDir(PORTD_ID , OUTPUT);   // Define Port D as output
   _delay_ms(50);
   
   /* code for ADC */
	ADMUX |=(1<<REFS0)|(1<<REFS1);
	ADCSRA |=(1<<ADEN)|(1<<ADATE)|(1<<ADPS0)|(1<<ADPS1)|(1<<ADPS2);

    int16_t COUNTA = 0;
	char SHOWA [3];
	char alert[6];

    send_a_command(lcd_DisplayOn);      // display on, cursor off, don't blink character
	_delay_ms(20);
	send_a_string("Temp(C)= ");
	_delay_ms(20);
	send_a_command(lcd_SetCursor + 0x40 + 8); // Set cursor to second line, 8th position
	_delay_ms(20);

    while(1) {
		ADCSRA |=(1<<ADSC);  // Start ADC conversion
		while(ADCSRA & (1<<ADSC)); // Wait for conversion complete
		
        COUNTA = ADC/4;     // Convert ADC value (adjust scaling factor if needed)
		itoa(COUNTA,SHOWA,10);
		
		if (COUNTA > 50) {
			_delay_ms(20);
			MDIO_voidSetPinValue(PORTC_ID, PIN1 , HIGH);  // Turn on red LED
			MDIO_voidSetPinValue(PORTC_ID, PIN0 , LOW);   // Ensure yellow LED is off
			MDIO_voidSetPinValue(PORTC_ID, PIN2 , LOW);   // Ensure green LED is off
			_delay_ms(20);
			strcpy(alert, "ALERT");
			} else if (COUNTA >= 30) {
			_delay_ms(50);
			MDIO_voidSetPinValue(PORTC_ID, PIN0 , HIGH);  // Turn on yellow LED
			MDIO_voidSetPinValue(PORTC_ID, PIN1 , LOW);   // Ensure red LED is off
			MDIO_voidSetPinValue(PORTC_ID, PIN2 , LOW);   // Ensure green LED is off
			strcpy(alert, "WARNING");
			} else {
			_delay_ms(50);
			MDIO_voidSetPinValue(PORTC_ID, PIN2 , HIGH);  // Turn on green LED
			MDIO_voidSetPinValue(PORTC_ID, PIN1 , LOW);   // Ensure red LED is off
			MDIO_voidSetPinValue(PORTC_ID, PIN0 , LOW);   // Ensure yellow LED is off
			strcpy(alert, "GOOD");
		}
		send_a_string(SHOWA);
		send_a_string(" ");
		send_a_string(alert);
		send_a_string ("  "); // Clear remaining digits
    }    

}

